﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TriviaGame
{
    internal class QuizItem
    {
        public string Question { get; }
        public string Answer { get; }

        //Add answer bank 
        private string[] answerBank;

        //Add an index for the correct answer
        public int correctAnswer { get; }


        //Constructor
        public QuizItem(string question, string answer)
        {
            Question = question;
            Answer = answer;
        }
        public QuizItem(string question, string[] sourceAnswerBank, int sourceAnswerIndex)
        {
            Question = question;
            answerBank = sourceAnswerBank;
            correctAnswer = sourceAnswerIndex;
        }

        // Display possible answers

        public string ShowPossibleAnswers()
        {
            StringBuilder result = new StringBuilder();

            
            for (int i = 0; i < answerBank.Length; i++)
            {
                result.Append($"{i + 1}: {answerBank[i]}\n");
            }
            return result.ToString();
        }


        public int GetAnswerBankSize()
        {
            return answerBank.Length;
        }


        
 
    }    
}