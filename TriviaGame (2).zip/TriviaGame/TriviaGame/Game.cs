﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using static System.Console;
using System.IO;
using System.ComponentModel.Design;

namespace TriviaGame
{
    internal class Game
    {
        private Player myPlayer;

        //public QuizItem[] quiz = new QuizItem[4];
        private List<QuizItem>quiz = new List<QuizItem>();

        // Add an attribute for the external data
        private string examData = "examData.txt";

       
        public Game()
        {
            //TODO: Finish Constructor
            StartGame();
            LoadQuiz();
            GameMenu();
        }
        public void PromptWait(string message)
        {
            WriteLine(message);
            WriteLine("hit any key to proceed...");
            ReadKey(true);
        }
        public void StartGame()
        {
            ForegroundColor = ConsoleColor.Green;
            WriteLine("Please enter your name");
            string name = ReadLine();
            WriteLine("Please enter your favorite color");
            string color = ReadLine();
            myPlayer = new Player(name, color);
            ForegroundColor = ConsoleColor.Gray;
            PromptWait($"Wonderful to meet you, {myPlayer.Name}, {myPlayer.FavoriteColor} my favorite color too!");
        }

        public void LoadQuiz()
        {
            //quiz[0] = new QuizItem("What is your favorite color?", myPlayer.FavoriteColor);
            //quiz[1] = new QuizItem("What is your favorite class?", "Art and Design");
            //quiz[2] = new QuizItem("What is your name?", myPlayer.Name);
            //quiz[3] = new QuizItem("What data type do you use for whole numbers?", "interger");

            //Add data from external file
            foreach(var item in File.ReadAllLines(examData)) 
            {
                //Create an array of strings
                var fields = item.Split(";;");

                //Create a quizitem and add to the list
                quiz.Add(new QuizItem(fields[0], new string[] { fields[1], fields[2], fields[3], fields[4] }, Convert.ToInt32(fields[5])));
            }
        }
        public void GameMenu()
        {
            bool run = true;
            while (run)
            {
                Clear();
                ForegroundColor = ConsoleColor.Red;
                WriteLine("1. Review\n2.Take Quz \n3.Quit Game");
                var info = ReadKey(true);

                switch (info.Key)
                {
                    case ConsoleKey.D1:
                        //TODO Call Review Method
                        PromptWait(ReviewTrivia());
                        break;
                    case ConsoleKey.D2:
                        TakeQuiz();

                        break;
                    //TODO Call TakeQuiz Method
                    case ConsoleKey.D3:
                        break;
                    default:
                        Clear();
                        PromptWait("You must enter 1,2,3");
                        break;

                }
            }
        




        }
        //TO DO: Create Review Method to just show the list of questions

        public string ReviewTrivia()
        {
            StringBuilder result = new StringBuilder();
            for (int i = 0; i<quiz.Count; i++)
            {
                result.Append($"{i + 1}: {quiz[i].Question}\n");
            }
            return result.ToString();
        }

        //TakeQuiz Method

        public void TakeQuiz()
        {
            Clear();

            for (int quizItemIndex = 0; quizItemIndex < quiz.Count; quizItemIndex++)
            {
                WriteLine(quiz[quizItemIndex].Question);
                WriteLine("Select your answer");

                WriteLine(quiz[quizItemIndex].ShowPossibleAnswers());


                if (int.TryParse(ReadLine(), out int answer))
                {
                    // If input is a number
                    if (answer >= 1 && answer <= quiz[quizItemIndex].GetAnswerBankSize())
                    {
                        answer--;
                        if (quiz[quizItemIndex].correctAnswer == answer)
                        {
                            //Correct
                            WriteLine("Correct!");
                            myPlayer.UpdateScore();
                        }
                        else
                        {
                            //Incorrect
                            WriteLine("Sorry this not correct.");
                        }
                    }
                    else
                    {
                        //number not in range
                        WriteLine("Sorry, that number is sooo wrong, Try again.");
                        //Repeat that question
                        quizItemIndex--;
                    }
                }
                else
                {
                    //number not in range
                    WriteLine("Sorry, that number is sooo wrong, Try again.");
                    //Repeat that question
                    quizItemIndex--;
                }

            }

            WriteLine($"You scored {myPlayer.Score} out of {quiz.Count}");




            


        }

    } 
}