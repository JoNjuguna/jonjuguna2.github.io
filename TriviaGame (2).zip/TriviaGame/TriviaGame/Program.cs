﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TriviaGame
{
    internal class Program
    {

        public static void Main(string[] args)
        {
            new Game();
        }
    }
}
