﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TriviaGame
{
    internal class Player
    {
        //Auto Implemented Property
        //Allows read access but not write

        public string Name { get; private set; }
        //allows read access only, cannot change after instantiation
        public string FavoriteColor { get; }
        public int Score { get; private set; }
        
        //Construtor
        public Player(string name, string color)
        {
            Name = name;
            FavoriteColor = color;
        }

        public int UpdateScore()
        {
            //Addint to the current value of score
            Score = Score + 1000;
            //Return the new state of Score 
            return Score;
        }
        
     
      
    }
}
