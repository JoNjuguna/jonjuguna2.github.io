﻿using Saving_Yummyville;

namespace Saving_Yummyville
{
    class Program
    {

        static void Main(string[] args)
        {
            Game game = new Game("Saving Yummyville");
            Console.ForegroundColor = ConsoleColor.Magenta;
            game.TitleText();
            Console.ReadKey();
            Console.Clear();
            game.Start();
            Console.ReadKey();
            Console.Clear();
            game.End();
           
        }
    }
}