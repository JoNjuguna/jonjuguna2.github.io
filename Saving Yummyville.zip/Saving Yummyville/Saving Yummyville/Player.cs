﻿
namespace Saving_Yummyville
{
    class Player
    {
        public string Name;
        public Item PlayerChoice;

        public Player()
        {
            PlayerChoice = new Item("Preztel Sticks","");
        }
    }

}
